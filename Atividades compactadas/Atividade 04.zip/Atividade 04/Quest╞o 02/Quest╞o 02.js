// 2 - Crie um programa em JavaScript que solicite ao usuário que digite um número e imprima todos os números de 1 até o número digitado usando a estrutura de repetição for.

let numero = parseInt(prompt("Digite um número:"));

for (let i = 1; i <= numero; i++) {
  console.log(i);
}