// 1 - Escreva um programa em JavaScript que imprima todos os números pares de 0 a 100 usando a estrutura de repetição while.

let i = 0;

while (i <= 100) {
  if (i % 2 === 0) {
    console.log(i);
  }
  i++;
}